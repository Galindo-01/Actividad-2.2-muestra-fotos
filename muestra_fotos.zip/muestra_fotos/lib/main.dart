import 'package:http/http.dart' as http;
import 'package:muestra_fotos/types/post.dart';


void main(List<String>arguments) async {
  var url= Uri.https('jsonplaceholder.typicode.com','/photos');

  try{
    var jsonPhotos = await http.get(url);
    if (jsonPhotos.statusCode == 200) {
      final photos = photoFromJson(jsonPhotos.body);
      for (var photo in photos) {
        print("Albumn: ${photo.albumId}");
        print("Codigo: ${photo.id}");
        print("Titulo: ${photo.title}");
        print("Url: ${photo.url}");
        print("thumbnailUrl ${photo.thumbnailUrl}");
        print("=================================================");
      }
    }else{
      print('NO se pudo conectar al servidor');
    }
  } catch (e){
    print(e.toString());
  }
}